//! Client-side game state: world, entities, inventory, input.

use bedrock_core::entity::{EntityKind, EntityWorld};
use bedrock_core::inventory::Inventory;
use bedrock_core::mesh::{mesh_chunk, ChunkMesh};
use bedrock_core::physics::{apply_look, tick_entity, PhysicsInput};
use bedrock_core::world::{ChunkPos, World};
use bedrock_core::Camera;
use bedrock_core::SkinStore;
use glam::Vec3;
use std::collections::HashMap;

pub struct GameState {
    pub world: World,
    pub entities: EntityWorld,
    pub inventory: Inventory,
    pub camera: Camera,
    pub input: PhysicsInput,
    pub look_dx: f32,
    pub look_dy: f32,
    pub meshes: HashMap<ChunkPos, ChunkMesh>,
    pub skins: SkinStore,
    pub paused: bool,
}

impl GameState {
    pub fn new() -> Self {
        let mut world = World::new("Bedrock-RS World", 42);
        // preload a few chunks around spawn
        for x in -2..=2 {
            for z in -2..=2 {
                world.get_or_create_chunk(ChunkPos::new(x, z));
            }
        }

        let mut entities = EntityWorld::default();
        let spawn = Vec3::new(0.5, 70.0, 0.5);
        entities.spawn_player(spawn);
        // a few mobs for testing
        entities.spawn_mob(EntityKind::Zombie, Vec3::new(5.0, 70.0, 3.0));
        entities.spawn_mob(EntityKind::Creeper, Vec3::new(-4.0, 70.0, 6.0));

        let mut meshes = HashMap::new();
        for (pos, chunk) in &world.chunks {
            meshes.insert(*pos, mesh_chunk(chunk));
        }

        let camera = entities
            .local_player()
            .map(Camera::from_entity)
            .unwrap_or_default();

        Self {
            world,
            entities,
            inventory: Inventory::default(),
            camera,
            input: PhysicsInput::default(),
            look_dx: 0.0,
            look_dy: 0.0,
            meshes,
            paused: false,
            skins: {
                let mut s = SkinStore::new();
                if let Ok(dir) = std::env::var("BEDROCK_SKINS") {
                    let _ = s.load_folder(dir);
                }
                let _ = s.load_folder("./skins");
                s
            },
        }
    }

    pub fn tick(&mut self, dt: f32) {
        if self.paused {
            return;
        }
        // look
        if let Some(p) = self.entities.local_player_mut() {
            apply_look(p, self.look_dx, self.look_dy, 0.15);
            self.look_dx = 0.0;
            self.look_dy = 0.0;
            tick_entity(p, &mut self.world, &self.input, dt);
            self.camera = Camera::from_entity(p);
        }
        // simple mob drift
        for e in &mut self.entities.entities {
            if e.kind == EntityKind::Player {
                continue;
            }
            e.yaw += 20.0 * dt;
            let dir = e.look_dir();
            e.pos.x += dir.x * 0.4 * dt;
            e.pos.z += dir.z * 0.4 * dt;
        }
    }

    pub fn use_item(&mut self) {
        self.inventory.use_selected();
    }

    pub fn scroll_hotbar(&mut self, delta: i32) {
        self.inventory.scroll_hotbar(delta);
    }

    pub fn select_hotbar(&mut self, i: usize) {
        self.inventory.select_hotbar(i);
    }
}

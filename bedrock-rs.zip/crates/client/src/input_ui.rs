//! Bedrock-style mobile touch HUD (D-pad left, action cluster right).
//! Layout matched to classic Bedrock touch controls.

use bedrock_core::ui::Rect;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UiAction {
    None,
    Play,
    Realms,
    Marketplace,
    Settings,
    Quit,
    Profile,
    OpenInventory,
    CloseInventory,
    Hotbar(usize),
    // movement d-pad
    MoveUp,
    MoveDown,
    MoveLeft,
    MoveRight,
    Sneak,
    // right cluster
    Jump,
    Attack,
    Use,       // interact
    Shield,
    Offhand,
}

#[derive(Debug, Clone)]
pub struct UiButton {
    pub id: &'static str,
    pub rect: Rect,
    pub action: UiAction,
    pub label: &'static str,
}

#[derive(Debug, Default)]
pub struct TouchControls {
    pub held: Vec<UiAction>,
    pub look_last: Option<(f32, f32)>,
    pub look_active: bool,
    pub joystick_origin: Option<(f32, f32)>,
    pub joystick_cur: (f32, f32),
}

impl TouchControls {
    pub fn set_held(&mut self, action: UiAction, down: bool) {
        if down {
            if !self.held.contains(&action) {
                self.held.push(action);
            }
        } else {
            self.held.retain(|a| *a != action);
        }
    }

    /// Touch started on empty area: left half = virtual stick, right half = look.
    pub fn on_touch_down(&mut self, x: f32, y: f32, screen_w: f32) {
        if x < screen_w * 0.5 {
            self.joystick_origin = Some((x, y));
            self.joystick_cur = (x, y);
        } else {
            self.look_last = Some((x, y));
            self.look_active = true;
        }
    }

    /// Returns (forward, strafe, look_dx, look_dy).
    pub fn on_touch_move(&mut self, x: f32, y: f32, screen_w: f32) -> (f32, f32, f32, f32) {
        let _ = screen_w;
        let mut out = (0.0, 0.0, 0.0, 0.0);
        if self.joystick_origin.is_some() && x < screen_w * 0.5 {
            self.joystick_cur = (x, y);
            let (f, s) = self.stick_vector();
            out.0 = f;
            out.1 = s;
        } else if self.look_active {
            if let Some((lx, ly)) = self.look_last {
                out.2 = x - lx;
                out.3 = y - ly;
            }
            self.look_last = Some((x, y));
        }
        out
    }

    pub fn on_touch_up(&mut self, _x: f32, _y: f32, _screen_w: f32) {
        self.joystick_origin = None;
        self.look_last = None;
        self.look_active = false;
    }

    pub fn stick_vector(&self) -> (f32, f32) {
        if let Some((ox, oy)) = self.joystick_origin {
            let dx = self.joystick_cur.0 - ox;
            let dy = self.joystick_cur.1 - oy;
            let r = 60.0;
            ((-dy / r).clamp(-1.0, 1.0), (dx / r).clamp(-1.0, 1.0))
        } else {
            (0.0, 0.0)
        }
    }

    pub fn is_held(&self, action: UiAction) -> bool {
        self.held.contains(&action)
    }

    /// Convert held d-pad into forward/strafe (-1..1).
    pub fn stick_from_dpad(&self) -> (f32, f32) {
        let mut f = 0.0;
        let mut s = 0.0;
        if self.is_held(UiAction::MoveUp) {
            f += 1.0;
        }
        if self.is_held(UiAction::MoveDown) {
            f -= 1.0;
        }
        if self.is_held(UiAction::MoveLeft) {
            s -= 1.0;
        }
        if self.is_held(UiAction::MoveRight) {
            s += 1.0;
        }
        (f, s)
    }
}

/// Layout copied from Bedrock reference screenshots.
/// HUD reference: 1600x900. Title reference: 2576x1159.
pub fn buttons_for_screen(screen: &str, w: f32, h: f32) -> Vec<UiButton> {
    let mut v = Vec::new();
    let mut b = |id: &'static str, x: f32, y: f32, bw: f32, bh: f32, action: UiAction, label: &'static str| {
        v.push(UiButton { id, rect: Rect::new(x, y, bw, bh), action, label });
    };
    match screen {
        "title_screen" => {
            let s = h / 1159.0;
            let cx = w * 0.5;
            let bw = 680.0 * s;
            let bh = 85.0 * s;
            let x0 = cx - bw * 0.5;
            b("play", x0, 525.0 * s, bw, bh, UiAction::Play, "Play");
            b("realms", x0, 620.0 * s, bw, bh, UiAction::Realms, "Realms");
            b("market", x0, 712.0 * s, bw, bh, UiAction::Marketplace, "Marketplace");
            b("settings", x0, 812.0 * s, 335.0 * s, bh, UiAction::Settings, "Settings");
            b("quit", x0 + 347.0 * s, 812.0 * s, 333.0 * s, bh, UiAction::Quit, "Quit");
            b("profile", cx - 946.0 * s, 815.0 * s, 310.0 * s, 85.0 * s, UiAction::Profile, "Profile");
        }
        "hotbar_screen" | "inventory_screen" => {
            let s = h / 900.0;
            // D-pad (left): up / left / sneak(center) / right / down
            b("dpad_up", 175.0 * s, 530.0 * s, 105.0 * s, 100.0 * s, UiAction::MoveUp, "^");
            b("dpad_left", 60.0 * s, 640.0 * s, 105.0 * s, 105.0 * s, UiAction::MoveLeft, "<");
            b("sneak", 175.0 * s, 640.0 * s, 105.0 * s, 105.0 * s, UiAction::Sneak, "Sneak");
            b("dpad_right", 287.0 * s, 640.0 * s, 105.0 * s, 105.0 * s, UiAction::MoveRight, ">");
            b("dpad_down", 175.0 * s, 752.0 * s, 105.0 * s, 103.0 * s, UiAction::MoveDown, "v");
            b("offhand", 445.0 * s, 745.0 * s, 75.0 * s, 72.0 * s, UiAction::Offhand, "Off-Hand");
            // Right cluster (anchored to right edge; reference width 1600)
            let rx = w - 1600.0 * s;
            b("shield", rx + 1188.0 * s, 632.0 * s, 98.0 * s, 96.0 * s, UiAction::Shield, "Shield");
            b("attack", rx + 1315.0 * s, 668.0 * s, 142.0 * s, 138.0 * s, UiAction::Attack, "Attack");
            b("jump", rx + 1480.0 * s, 688.0 * s, 96.0 * s, 94.0 * s, UiAction::Jump, "Jump/Fly");
            b("inv", rx + 1085.0 * s, 745.0 * s, 72.0 * s, 72.0 * s, UiAction::OpenInventory, "Inventory");
            b("interact", rx + 1190.0 * s, 762.0 * s, 96.0 * s, 98.0 * s, UiAction::Use, "Interact");
            // hotbar slots, bottom center
            let slot = 36.0 * s;
            let start_x = w * 0.5 - slot * 4.5 - 4.0 * s * 4.0;
            let y = h - slot - 6.0 * s;
            for i in 0..9 {
                b("hotbar", start_x + i as f32 * (slot + 4.0 * s), y, slot, slot, UiAction::Hotbar(i), "");
            }
        }
        _ => {}
    }
    if screen == "inventory_screen" {
        b("close_inv", 0.0, 0.0, w, h, UiAction::CloseInventory, "");
    }
    v
}

pub fn hit_test(buttons: &[UiButton], x: f32, y: f32) -> UiAction {
    let mut action = UiAction::None;
    for b in buttons {
        let r = &b.rect;
        if x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h {
            if b.action == UiAction::CloseInventory && action != UiAction::None {
                continue;
            }
            action = b.action;
        }
    }
    action
}

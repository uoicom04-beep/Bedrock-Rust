//! Minimal wgpu UI renderer.
//! Draws colored panels + textured quads for Bedrock-style screens.
//! Real textures come from ResourcePackManager after extract.

use anyhow::{Context, Result};
use crate::input_ui::{buttons_for_screen, UiAction};
use bedrock_core::ui::Rect;
use bytemuck::{Pod, Zeroable};
use glam::Vec2;
use std::sync::Arc;
use wgpu::util::DeviceExt;
use winit::window::Window;

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct Vertex {
    pos: [f32; 2],
    uv: [f32; 2],
    color: [f32; 4],
}

pub struct UiQuad {
    pub rect: Rect,
    pub color: [f32; 4],
    pub z: f32,
}

pub struct Renderer {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    size: winit::dpi::PhysicalSize<u32>,
    pipeline: wgpu::RenderPipeline,
    vertex_buffer: wgpu::Buffer,
    max_vertices: u64,
    _selected_hotbar: usize,
}

impl Renderer {
    pub async fn new(window: Arc<Window>) -> Result<Self> {
        let size = window.inner_size();
        let instance = wgpu::Instance::default();
        let surface = instance
            .create_surface(window.clone())
            .context("create surface")?;
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .context("no adapter")?;
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("bedrock-rs"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                    memory_hints: Default::default(),
                },
                None,
            )
            .await
            .context("request device")?;

        let caps = surface.get_capabilities(&adapter);
        let format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);

        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("ui_shader"),
            source: wgpu::ShaderSource::Wgsl(SHADER.into()),
        });

        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("ui_pipeline_layout"),
            bind_group_layouts: &[],
            push_constant_ranges: &[],
        });

        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("ui_pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Vertex>() as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32x2, 2 => Float32x4],
                }],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                ..Default::default()
            },
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        let max_vertices = 16384u64;
        let vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui_vertices"),
            size: max_vertices * std::mem::size_of::<Vertex>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        Ok(Self {
            surface,
            device,
            queue,
            config,
            size,
            pipeline,
            vertex_buffer,
            max_vertices,
            _selected_hotbar: 0,
        })
    }

    pub fn resize(&mut self, new_size: winit::dpi::PhysicalSize<u32>) {
        if new_size.width > 0 && new_size.height > 0 {
            self.size = new_size;
            self.config.width = new_size.width;
            self.config.height = new_size.height;
            self.surface.configure(&self.device, &self.config);
        }
    }

    /// Build quads for the current screen (fallback layouts when real JSON art not yet textured).
    pub fn build_screen_quads(&self, screen: &str) -> Vec<UiQuad> {
        let w = self.size.width as f32;
        let h = self.size.height as f32;
        let mut q = Vec::new();

        match screen {
            "title_screen" => {
                // sky + grass placeholder until panorama texture is extracted
                q.push(UiQuad { rect: Rect::new(0.0, 0.0, w, h), color: [0.45, 0.65, 0.95, 1.0], z: 0.0 });
                q.push(UiQuad { rect: Rect::new(0.0, h * 0.55, w, h * 0.45), color: [0.33, 0.52, 0.22, 1.0], z: 0.5 });
                let s = h / 1159.0;
                // logo
                q.push(UiQuad { rect: Rect::new(w * 0.5 - 520.0 * s, 95.0 * s, 1040.0 * s, 180.0 * s), color: [0.78, 0.74, 0.72, 1.0], z: 1.0 });
                for bt in buttons_for_screen("title_screen", w, h) {
                    let color = match bt.id {
                        "realms" => [0.45, 0.27, 0.90, 1.0],
                        "quit" => [0.80, 0.18, 0.18, 1.0],
                        _ => [0.82, 0.82, 0.84, 1.0],
                    };
                    // dark border then face
                    let r = bt.rect;
                    q.push(UiQuad { rect: Rect::new(r.x - 2.0, r.y - 2.0, r.w + 4.0, r.h + 4.0), color: [0.1, 0.1, 0.1, 1.0], z: 1.8 });
                    q.push(UiQuad { rect: r, color, z: 2.0 });
                }
                // skin preview, right
                q.push(UiQuad { rect: Rect::new(w - 660.0 * s, 520.0 * s, 160.0 * s, 380.0 * s), color: [0.93, 0.45, 0.65, 1.0], z: 2.0 });
            }
            "hotbar_screen" => {
                q.push(UiQuad { rect: Rect::new(0.0, 0.0, w, h), color: [0.45, 0.65, 0.95, 1.0], z: 0.0 });
                q.push(UiQuad { rect: Rect::new(0.0, h * 0.62, w, h * 0.38), color: [0.45, 0.42, 0.22, 1.0], z: 0.5 });
                for bt in buttons_for_screen("hotbar_screen", w, h) {
                    if let UiAction::Hotbar(i) = bt.action {
                        let sel = i == self._selected_hotbar;
                        q.push(UiQuad { rect: bt.rect, color: if sel { [0.9, 0.9, 0.9, 0.95] } else { [0.2, 0.2, 0.2, 0.85] }, z: 2.0 });
                    } else {
                        // semi-transparent gray touch buttons with dark outline
                        let r = bt.rect;
                        q.push(UiQuad { rect: Rect::new(r.x - 2.0, r.y - 2.0, r.w + 4.0, r.h + 4.0), color: [0.15, 0.15, 0.15, 0.7], z: 2.9 });
                        q.push(UiQuad { rect: r, color: [0.50, 0.50, 0.48, 0.80], z: 3.0 });
                    }
                }
            }
            "inventory_screen" => {
                q.push(UiQuad {
                    rect: Rect::new(0.0, 0.0, w, h),
                    color: [0.0, 0.0, 0.0, 0.55],
                    z: 0.0,
                });
                let pw = 352.0;
                let ph = 332.0;
                q.push(UiQuad {
                    rect: Rect::new(w * 0.5 - pw * 0.5, h * 0.5 - ph * 0.5, pw, ph),
                    color: [0.78, 0.78, 0.78, 1.0],
                    z: 1.0,
                });
            }
            _ => {
                q.push(UiQuad {
                    rect: Rect::new(0.0, 0.0, w, h),
                    color: [0.1, 0.1, 0.12, 1.0],
                    z: 0.0,
                });
            }
        }
        q
    }

    pub fn render(&mut self, screen: &str) -> Result<()> {
        let quads = self.build_screen_quads(screen);
        let w = self.size.width as f32;
        let h = self.size.height as f32;

        let mut vertices: Vec<Vertex> = Vec::with_capacity(quads.len() * 6);
        for q in &quads {
            let x0 = (q.rect.x / w) * 2.0 - 1.0;
            let y0 = 1.0 - (q.rect.y / h) * 2.0;
            let x1 = ((q.rect.x + q.rect.w) / w) * 2.0 - 1.0;
            let y1 = 1.0 - ((q.rect.y + q.rect.h) / h) * 2.0;
            let c = q.color;
            let v = |x: f32, y: f32, u: f32, v: f32| Vertex {
                pos: [x, y],
                uv: [u, v],
                color: c,
            };
            // two triangles
            vertices.push(v(x0, y0, 0.0, 0.0));
            vertices.push(v(x1, y0, 1.0, 0.0));
            vertices.push(v(x0, y1, 0.0, 1.0));
            vertices.push(v(x1, y0, 1.0, 0.0));
            vertices.push(v(x1, y1, 1.0, 1.0));
            vertices.push(v(x0, y1, 0.0, 1.0));
        }

        if vertices.len() as u64 > self.max_vertices {
            vertices.truncate(self.max_vertices as usize);
        }
        self.queue
            .write_buffer(&self.vertex_buffer, 0, bytemuck::cast_slice(&vertices));

        let frame = self.surface.get_current_texture()?;
        let view = frame
            .texture
            .create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("ui_encoder"),
            });

        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("ui_pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.05,
                            g: 0.05,
                            b: 0.07,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.pipeline);
            pass.set_vertex_buffer(0, self.vertex_buffer.slice(..));
            pass.draw(0..vertices.len() as u32, 0..1);
        }

        self.queue.submit(Some(encoder.finish()));
        frame.present();
        Ok(())
    }

    /// Render game HUD for current state. World 3D mesh upload comes next iteration;
    /// for now we show the UI layer with live hotbar selection.
    pub fn render_game(&mut self, game: &crate::game::GameState, screen: &str) -> Result<()> {
        // Prefer inventory / hotbar screens; highlight selected slot via build
        let screen = if screen == "inventory_screen" {
            "inventory_screen"
        } else {
            "hotbar_screen"
        };
        // stash selected for build_screen_quads override
        self._selected_hotbar = game.inventory.selected;
        self.render(screen)
    }
}

const SHADER: &str = r#"
struct VertexInput {
    @location(0) pos: vec2<f32>,
    @location(1) uv: vec2<f32>,
    @location(2) color: vec4<f32>,
};
struct VertexOutput {
    @builtin(position) clip: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) color: vec4<f32>,
};
@vertex
fn vs_main(in: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    out.clip = vec4<f32>(in.pos, 0.0, 1.0);
    out.uv = in.uv;
    out.color = in.color;
    return out;
}
@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    return in.color;
}
"#;

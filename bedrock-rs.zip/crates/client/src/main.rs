fn main() -> anyhow::Result<()> {
    #[cfg(not(target_os = "android"))]
    return bedrock_client::desktop_main();
    #[cfg(target_os = "android")]
    Ok(())
}

//! Bedrock-RS client library (desktop bin + Android cdylib).

mod game;
mod input_ui;
mod renderer;

use anyhow::Result;
use bedrock_core::ui::{builtin_hotbar, builtin_title, UiManager, UiScreen};
use bedrock_core::{ResourcePackManager, ENGINE_NAME, ENGINE_VERSION};
use game::GameState;
use input_ui::{buttons_for_screen, hit_test, TouchControls, UiAction};
use log::info;
use renderer::Renderer;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;
use winit::application::ApplicationHandler;
use winit::event::{DeviceEvent, ElementState, MouseButton, MouseScrollDelta, WindowEvent};
use winit::event_loop::{ActiveEventLoop, EventLoop};
use winit::keyboard::{KeyCode, PhysicalKey};
use winit::window::{CursorGrabMode, Window, WindowId};

struct App {
    window: Option<Arc<Window>>,
    renderer: Option<Renderer>,
    packs: ResourcePackManager,
    ui: UiManager,
    game: GameState,
    current_screen: String,
    last_frame: Instant,
    cursor_grabbed: bool,
    touch: TouchControls,
    screen_w: f32,
    screen_h: f32,
    mouse_x: f32,
    mouse_y: f32,
    quit: bool,
}

impl App {
    fn apply_action(&mut self, action: UiAction, down: bool) {
        match action {
            UiAction::None => {}
            UiAction::Play if down => {
                self.current_screen = "hotbar_screen".into();
                info!("Play → world HUD");
            }
            UiAction::Realms if down => info!("Realms (stub — online service)"),
            UiAction::Marketplace if down => info!("Marketplace (stub)"),
            UiAction::Quit if down => {
                info!("Quit");
                self.quit = true;
            }
            UiAction::Profile if down => info!("Profile / skin select — put PNGs in ./skins"),
            UiAction::Settings if down => info!("Settings (stub)"),
            UiAction::OpenInventory if down => {
                self.current_screen = "inventory_screen".into();
            }
            UiAction::CloseInventory if down => {
                self.current_screen = "hotbar_screen".into();
            }
            UiAction::Hotbar(i) if down => self.game.select_hotbar(i),
            UiAction::Jump => {
                self.touch.set_held(UiAction::Jump, down);
                self.game.input.jump = down;
            }
            UiAction::Attack if down => info!("Attack"),
            UiAction::Use if down => self.game.use_item(),
            UiAction::Sneak => {
                self.touch.set_held(UiAction::Sneak, down);
                self.game.input.sneak = down;
            }
            UiAction::Shield => self.touch.set_held(UiAction::Shield, down),
            UiAction::Offhand if down => info!("Off-hand swap"),
            UiAction::MoveUp | UiAction::MoveDown | UiAction::MoveLeft | UiAction::MoveRight => {
                self.touch.set_held(action, down);
            }
            _ => {}
        }
        // refresh movement from d-pad
        let (f, s) = self.touch.stick_from_dpad();
        // only override if any d-pad held; else leave keyboard values
        if self.touch.is_held(UiAction::MoveUp)
            || self.touch.is_held(UiAction::MoveDown)
            || self.touch.is_held(UiAction::MoveLeft)
            || self.touch.is_held(UiAction::MoveRight)
        {
            self.game.input.forward = f;
            self.game.input.strafe = s;
        } else if !down {
            // on release, if no d-pad left, zero stick axes (keyboard may still set next frame)
            let any = self.touch.is_held(UiAction::MoveUp)
                || self.touch.is_held(UiAction::MoveDown)
                || self.touch.is_held(UiAction::MoveLeft)
                || self.touch.is_held(UiAction::MoveRight);
            if !any {
                // keep keyboard; zero only if no keys — simplified: zero when last d-pad released
                self.game.input.forward = 0.0;
                self.game.input.strafe = 0.0;
            }
        }
    }
}

impl ApplicationHandler for App {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let title = format!(
            "{} {} — click UI | WASD | touch stick | 1-9 | E | Esc",
            ENGINE_NAME, ENGINE_VERSION
        );
        let attrs = Window::default_attributes()
            .with_title(title)
            .with_inner_size(winit::dpi::LogicalSize::new(1280.0, 720.0));
        let window = Arc::new(event_loop.create_window(attrs).expect("window"));
        let size = window.inner_size();
        self.screen_w = size.width as f32;
        self.screen_h = size.height as f32;
        info!("Window ready — clickable UI + touch controls active");
        let renderer = pollster::block_on(Renderer::new(window.clone())).expect("renderer");
        self.renderer = Some(renderer);
        self.window = Some(window);
        self.last_frame = Instant::now();
        self.current_screen = "title_screen".into();
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        _id: WindowId,
        event: WindowEvent,
    ) {
        match event {
            WindowEvent::CloseRequested => event_loop.exit(),
            WindowEvent::Resized(size) => {
                self.screen_w = size.width as f32;
                self.screen_h = size.height as f32;
                if let Some(r) = self.renderer.as_mut() {
                    r.resize(size);
                }
            }
            WindowEvent::CursorMoved { position, .. } => {
                self.mouse_x = position.x as f32;
                self.mouse_y = position.y as f32;
            }
            WindowEvent::RedrawRequested => {
                let now = Instant::now();
                let dt = (now - self.last_frame).as_secs_f32().min(0.05);
                self.last_frame = now;

                // apply virtual stick if active
                let (fwd, strf) = self.touch.stick_vector();
                if self.touch.joystick_origin.is_some() {
                    self.game.input.forward = fwd;
                    self.game.input.strafe = strf;
                }

                self.game.tick(dt);
                // jump from UI is one-shot
                if self.game.input.jump {
                    // leave true for one physics tick then clear if not holding space
                }

                if let Some(r) = self.renderer.as_mut() {
                    if let Err(e) = r.render_game(&self.game, &self.current_screen) {
                        log::error!("render: {e:#}");
                    }
                }
            }
            WindowEvent::KeyboardInput { event, .. } => {
                let pressed = event.state == ElementState::Pressed;
                if let PhysicalKey::Code(code) = event.physical_key {
                    match code {
                        KeyCode::KeyW => self.game.input.forward = if pressed { 1.0 } else { 0.0 },
                        KeyCode::KeyS => self.game.input.forward = if pressed { -1.0 } else { 0.0 },
                        KeyCode::KeyA => self.game.input.strafe = if pressed { -1.0 } else { 0.0 },
                        KeyCode::KeyD => self.game.input.strafe = if pressed { 1.0 } else { 0.0 },
                        KeyCode::Space => self.game.input.jump = pressed,
                        KeyCode::ShiftLeft => self.game.input.sneak = pressed,
                        KeyCode::ControlLeft => self.game.input.sprint = pressed,
                        KeyCode::Escape if pressed => {
                            self.cursor_grabbed = false;
                            if let Some(w) = &self.window {
                                let _ = w.set_cursor_grab(CursorGrabMode::None);
                                w.set_cursor_visible(true);
                            }
                            if self.current_screen == "inventory_screen" {
                                self.current_screen = "hotbar_screen".into();
                            } else if self.current_screen == "hotbar_screen" {
                                self.current_screen = "title_screen".into();
                            }
                        }
                        KeyCode::KeyE if pressed => {
                            self.current_screen = if self.current_screen == "inventory_screen" {
                                "hotbar_screen".into()
                            } else {
                                "inventory_screen".into()
                            };
                        }
                        KeyCode::Digit1 if pressed => self.game.select_hotbar(0),
                        KeyCode::Digit2 if pressed => self.game.select_hotbar(1),
                        KeyCode::Digit3 if pressed => self.game.select_hotbar(2),
                        KeyCode::Digit4 if pressed => self.game.select_hotbar(3),
                        KeyCode::Digit5 if pressed => self.game.select_hotbar(4),
                        KeyCode::Digit6 if pressed => self.game.select_hotbar(5),
                        KeyCode::Digit7 if pressed => self.game.select_hotbar(6),
                        KeyCode::Digit8 if pressed => self.game.select_hotbar(7),
                        KeyCode::Digit9 if pressed => self.game.select_hotbar(8),
                        _ => {}
                    }
                }
            }
            WindowEvent::MouseInput { state, button, .. } => {
                if state == ElementState::Pressed && button == MouseButton::Left {
                    // UI hit-test first (when not fully grabbed look, or always on title/inv)
                    let buttons = buttons_for_screen(
                        &self.current_screen,
                        self.screen_w,
                        self.screen_h,
                    );
                    let action = hit_test(&buttons, self.mouse_x, self.mouse_y);
                    if action != UiAction::None {
                        self.apply_action(action, true);
                    } else if self.current_screen == "hotbar_screen" && !self.cursor_grabbed {
                        if let Some(w) = &self.window {
                            let _ = w.set_cursor_grab(CursorGrabMode::Confined);
                            w.set_cursor_visible(false);
                            self.cursor_grabbed = true;
                        }
                    }
                    // treat as touch start for stick (desktop testing)
                    self.touch.on_touch_down(self.mouse_x, self.mouse_y, self.screen_w);
                }
                if state == ElementState::Released && button == MouseButton::Left {
                    let buttons = buttons_for_screen(&self.current_screen, self.screen_w, self.screen_h);
                    let action = hit_test(&buttons, self.mouse_x, self.mouse_y);
                    if action != UiAction::None {
                        self.apply_action(action, false);
                    }

                    self.touch.on_touch_up(self.mouse_x, self.mouse_y, self.screen_w);
                    if self.touch.joystick_origin.is_none() {
                        // clear stick-driven movement if keyboard not held — keep keyboard values
                    }
                }
                if state == ElementState::Pressed && button == MouseButton::Right {
                    self.game.use_item();
                }
            }
            WindowEvent::Touch(touch) => {
                use winit::event::TouchPhase;
                let x = touch.location.x as f32;
                let y = touch.location.y as f32;
                match touch.phase {
                    TouchPhase::Started => {
                        let buttons =
                            buttons_for_screen(&self.current_screen, self.screen_w, self.screen_h);
                        let action = hit_test(&buttons, x, y);
                        if action != UiAction::None {
                            self.apply_action(action, true);
                        } else {
                            self.touch.on_touch_down(x, y, self.screen_w);
                        }
                    }
                    TouchPhase::Moved => {
                        let (fwd, strf, ldx, ldy) =
                            self.touch.on_touch_move(x, y, self.screen_w);
                        if self.touch.joystick_origin.is_some() {
                            self.game.input.forward = fwd;
                            self.game.input.strafe = strf;
                        }
                        self.game.look_dx += ldx;
                        self.game.look_dy += ldy;
                    }
                    TouchPhase::Ended | TouchPhase::Cancelled => {
                        self.touch.on_touch_up(x, y, self.screen_w);
                        if self.touch.joystick_origin.is_none() {
                            self.game.input.forward = 0.0;
                            self.game.input.strafe = 0.0;
                        }
                        self.game.input.jump = false;
                    }
                }
            }
            WindowEvent::MouseWheel { delta, .. } => {
                let d = match delta {
                    MouseScrollDelta::LineDelta(_, y) => y.signum() as i32,
                    MouseScrollDelta::PixelDelta(p) => p.y.signum() as i32,
                };
                self.game.scroll_hotbar(-d);
            }
            _ => {}
        }
    }

    fn device_event(
        &mut self,
        _event_loop: &ActiveEventLoop,
        _device_id: winit::event::DeviceId,
        event: DeviceEvent,
    ) {
        if let DeviceEvent::MouseMotion { delta } = event {
            if self.cursor_grabbed {
                self.game.look_dx += delta.0 as f32;
                self.game.look_dy += delta.1 as f32;
            }
        }
    }

    fn about_to_wait(&mut self, event_loop: &ActiveEventLoop) {
        if self.quit {
            event_loop.exit();
        }
        if let Some(w) = &self.window {
            w.request_redraw();
        }
    }
}

pub fn run(event_loop: EventLoop<()>) -> Result<()> {
    info!("{} {} — full UI click + touch controls", ENGINE_NAME, ENGINE_VERSION);

    let mut packs = ResourcePackManager::new();
    let mut ui = UiManager::new();
    let example = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../assets/resource_packs");
    if example.is_dir() {
        let _ = packs.load_folder(&example);
    }
    ui.screens.insert(
        "title_screen".into(),
        UiScreen {
            name: "title_screen".into(),
            path: PathBuf::from("builtin"),
            root: builtin_title(),
        },
    );
    ui.screens.insert(
        "hotbar_screen".into(),
        UiScreen {
            name: "hotbar_screen".into(),
            path: PathBuf::from("builtin"),
            root: builtin_hotbar(),
        },
    );

    let mut app = App {
        window: None,
        renderer: None,
        packs,
        ui,
        game: GameState::new(),
        current_screen: "title_screen".into(),
        last_frame: Instant::now(),
        cursor_grabbed: false,
        touch: TouchControls::default(),
        screen_w: 1280.0,
        screen_h: 720.0,
        mouse_x: 0.0,
        mouse_y: 0.0,
        quit: false,
    };
    event_loop.run_app(&mut app)?;
    Ok(())
}

#[cfg(not(target_os = "android"))]
pub fn desktop_main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();
    run(EventLoop::new()?)
}

#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(app: winit::platform::android::activity::AndroidApp) {
    use winit::platform::android::EventLoopBuilderExtAndroid;
    android_logger::init_once(
        android_logger::Config::default().with_max_level(log::LevelFilter::Info).with_tag("BedrockRS"),
    );
    let event_loop = EventLoop::builder().with_android_app(app).build().expect("event loop");
    if let Err(e) = run(event_loop) {
        log::error!("run failed: {e:#}");
    }
}

//! Native Rust Addon API for Bedrock-RS.
//! Compile as cdylib → load by the client/server like a Bedrock behavior pack
//! but with real Rust code instead of JavaScript.

use log::info;

/// Called once when the addon is loaded.
#[no_mangle]
pub extern "C" fn bedrock_addon_init() {
    info!("[addon] Soft example addon loaded");
}

/// Called every server tick (or client tick when relevant).
#[no_mangle]
pub extern "C" fn bedrock_addon_tick(_dt: f32) {}

/// Example: modify a block break event (return 1 = cancel).
#[no_mangle]
pub extern "C" fn bedrock_addon_on_block_break(
    _x: i32,
    _y: i32,
    _z: i32,
    _block_id: u32,
) -> i32 {
    0
}

/// Manifest-style info so the loader can show the addon in the UI.
#[no_mangle]
pub extern "C" fn bedrock_addon_name() -> *const u8 {
    b"Example Rust Addon\0".as_ptr()
}

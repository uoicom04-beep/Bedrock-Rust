use byteorder::{LittleEndian, ReadBytesExt, WriteBytesExt};
use std::io::{Cursor, Read, Write};

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PacketId {
    Login = 0x01,
    PlayStatus = 0x02,
    ServerToClientHandshake = 0x03,
    ClientToServerHandshake = 0x04,
    Disconnect = 0x05,
    ResourcePacksInfo = 0x06,
    ResourcePackStack = 0x07,
    ResourcePackClientResponse = 0x08,
    Text = 0x09,
    StartGame = 0x0b,
    // ... hundreds more in real Bedrock
    Unknown = 0xff,
}

impl From<u8> for PacketId {
    fn from(v: u8) -> Self {
        match v {
            0x01 => Self::Login,
            0x02 => Self::PlayStatus,
            0x05 => Self::Disconnect,
            0x06 => Self::ResourcePacksInfo,
            0x09 => Self::Text,
            0x0b => Self::StartGame,
            _ => Self::Unknown,
        }
    }
}

#[derive(Debug, Clone)]
pub enum Packet {
    Login { protocol: u32, raw: Vec<u8> },
    PlayStatus { status: i32 },
    Disconnect { message: String },
    Text { message: String },
    StartGame { /* fields later */ },
    Raw { id: PacketId, data: Vec<u8> },
}

impl Packet {
    pub fn id(&self) -> PacketId {
        match self {
            Packet::Login { .. } => PacketId::Login,
            Packet::PlayStatus { .. } => PacketId::PlayStatus,
            Packet::Disconnect { .. } => PacketId::Disconnect,
            Packet::Text { .. } => PacketId::Text,
            Packet::StartGame { .. } => PacketId::StartGame,
            Packet::Raw { id, .. } => *id,
        }
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        buf.write_u8(self.id() as u8).ok();
        match self {
            Packet::PlayStatus { status } => {
                buf.write_i32::<LittleEndian>(*status).ok();
            }
            Packet::Disconnect { message } => {
                write_string(&mut buf, message);
            }
            Packet::Text { message } => {
                buf.write_u8(0).ok(); // type
                write_string(&mut buf, message);
            }
            Packet::Raw { data, .. } => buf.extend_from_slice(data),
            _ => {}
        }
        buf
    }

    pub fn decode(data: &[u8]) -> Option<Self> {
        if data.is_empty() {
            return None;
        }
        let id = PacketId::from(data[0]);
        let mut cur = Cursor::new(&data[1..]);
        match id {
            PacketId::PlayStatus => {
                let status = cur.read_i32::<LittleEndian>().ok()?;
                Some(Packet::PlayStatus { status })
            }
            PacketId::Disconnect => {
                let message = read_string(&mut cur).unwrap_or_default();
                Some(Packet::Disconnect { message })
            }
            PacketId::Text => {
                let _ty = cur.read_u8().ok()?;
                let message = read_string(&mut cur).unwrap_or_default();
                Some(Packet::Text { message })
            }
            _ => Some(Packet::Raw {
                id,
                data: data[1..].to_vec(),
            }),
        }
    }
}

fn write_string(w: &mut impl Write, s: &str) {
    let bytes = s.as_bytes();
    let _ = w.write_u32::<LittleEndian>(bytes.len() as u32);
    let _ = w.write_all(bytes);
}

fn read_string(r: &mut impl Read) -> Option<String> {
    let len = r.read_u32::<LittleEndian>().ok()? as usize;
    let mut buf = vec![0u8; len];
    r.read_exact(&mut buf).ok()?;
    String::from_utf8(buf).ok()
}

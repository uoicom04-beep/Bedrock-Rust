//! Bedrock network protocol skeleton (RakNet + game packets).
//! Full implementation is large; this gives the packet frame and a few stubs.

pub mod packet;
pub mod raknet;

pub use packet::{PacketId, Packet};
pub use raknet::RakNetPeer;

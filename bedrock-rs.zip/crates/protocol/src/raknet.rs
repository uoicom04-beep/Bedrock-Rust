//! Minimal RakNet peer stub.
//! Real Bedrock uses RakNet (UDP) with offline + online messages.
//! This is only the shape so the server/client compile.

use anyhow::Result;
use std::net::SocketAddr;

#[derive(Debug)]
pub struct RakNetPeer {
    pub addr: SocketAddr,
    pub connected: bool,
}

impl RakNetPeer {
    pub fn new(addr: SocketAddr) -> Self {
        Self {
            addr,
            connected: false,
        }
    }

    pub async fn connect(&mut self) -> Result<()> {
        log::info!("RakNet connect stub → {}", self.addr);
        self.connected = true;
        Ok(())
    }

    pub async fn send(&self, data: &[u8]) -> Result<()> {
        log::debug!("RakNet send {} bytes to {}", data.len(), self.addr);
        Ok(())
    }
}

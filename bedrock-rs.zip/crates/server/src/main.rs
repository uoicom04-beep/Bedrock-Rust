//! Bedrock-RS dedicated server skeleton.
//! Listens on UDP 19132 (Bedrock default) — full RakNet later.

use anyhow::Result;
use bedrock_core::{ENGINE_NAME, ENGINE_VERSION, GAME_VERSION, PROTOCOL_VERSION};
use log::info;
use std::net::SocketAddr;
use tokio::net::UdpSocket;

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();
    info!(
        "{} {} server (protocol {}, game {})",
        ENGINE_NAME, ENGINE_VERSION, PROTOCOL_VERSION, GAME_VERSION
    );

    let addr: SocketAddr = "0.0.0.0:19132".parse()?;
    let socket = UdpSocket::bind(addr).await?;
    info!("Listening on {} (Bedrock default port)", addr);

    let mut buf = vec![0u8; 2048];
    loop {
        let (len, peer) = socket.recv_from(&mut buf).await?;
        log::debug!("UDP {} bytes from {}", len, peer);
        // TODO: RakNet offline message → connection → Login packet
        // For now just log so the process stays alive.
    }
}

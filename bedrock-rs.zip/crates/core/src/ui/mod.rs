//! Bedrock-style JSON UI loader + minimal runtime.
//! Loads the same shape of files the real game uses (ui/*.json).
//! Actual art/JSON must come from the player's own install via extract script.

use anyhow::{Context, Result};
use serde::Deserialize;
use serde_json::Value;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Deserialize)]
pub struct UiControl {
    #[serde(default)]
    pub r#type: Option<String>,
    #[serde(default)]
    pub anchor_from: Option<String>,
    #[serde(default)]
    pub anchor_to: Option<String>,
    #[serde(default)]
    pub size: Option<Vec<Value>>,
    #[serde(default)]
    pub offset: Option<Vec<Value>>,
    #[serde(default)]
    pub texture: Option<String>,
    #[serde(default)]
    pub layer: Option<i32>,
    #[serde(default)]
    pub controls: Option<Vec<HashMap<String, Value>>>,
    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

#[derive(Debug, Clone)]
pub struct UiScreen {
    pub name: String,
    pub path: PathBuf,
    pub root: Value,
}

#[derive(Debug, Default)]
pub struct UiManager {
    pub screens: HashMap<String, UiScreen>,
    pub namespace: HashMap<String, Value>,
}

impl UiManager {
    pub fn new() -> Self {
        Self::default()
    }

    /// Load every .json under a ui/ folder (Bedrock layout).
    pub fn load_folder(&mut self, ui_root: impl AsRef<Path>) -> Result<usize> {
        let ui_root = ui_root.as_ref();
        if !ui_root.is_dir() {
            return Ok(0);
        }
        let mut count = 0;
        for entry in walkdir(ui_root)? {
            if entry.extension().and_then(|e| e.to_str()) != Some("json") {
                continue;
            }
            let data = fs::read_to_string(&entry)
                .with_context(|| format!("read {}", entry.display()))?;
            let root: Value = serde_json::from_str(&data)
                .with_context(|| format!("parse {}", entry.display()))?;
            let name = entry
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("unknown")
                .to_string();
            self.screens.insert(
                name.clone(),
                UiScreen {
                    name: name.clone(),
                    path: entry,
                    root,
                },
            );
            count += 1;
        }
        log::info!("UI: loaded {} screen/definition files from {}", count, ui_root.display());
        Ok(count)
    }

    pub fn get(&self, name: &str) -> Option<&UiScreen> {
        self.screens.get(name)
    }

    pub fn list(&self) -> Vec<&str> {
        let mut v: Vec<&str> = self.screens.keys().map(|s| s.as_str()).collect();
        v.sort();
        v
    }
}

fn walkdir(dir: &Path) -> Result<Vec<PathBuf>> {
    let mut out = Vec::new();
    fn rec(d: &Path, out: &mut Vec<PathBuf>) -> Result<()> {
        for e in fs::read_dir(d)? {
            let e = e?;
            let p = e.path();
            if p.is_dir() {
                rec(&p, out)?;
            } else {
                out.push(p);
            }
        }
        Ok(())
    }
    rec(dir, &mut out)?;
    Ok(out)
}

/// Simple layout rect used by the client renderer.
#[derive(Debug, Clone, Copy)]
pub struct Rect {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
}

impl Rect {
    pub fn new(x: f32, y: f32, w: f32, h: f32) -> Self {
        Self { x, y, w, h }
    }
}

/// Built-in fallback screens so the client always has something to show
/// even before real Bedrock UI files are extracted.
pub fn builtin_hotbar() -> Value {
    serde_json::json!({
        "namespace": "bedrock_rs",
        "hotbar_screen": {
            "type": "screen",
            "controls": [
                {
                    "hotbar_panel": {
                        "type": "panel",
                        "anchor_from": "bottom_middle",
                        "anchor_to": "bottom_middle",
                        "size": [364, 44],
                        "offset": [0, -4],
                        "texture": "textures/ui/hotbar_base"
                    }
                }
            ]
        }
    })
}

pub fn builtin_title() -> Value {
    serde_json::json!({
        "namespace": "bedrock_rs",
        "title_screen": {
            "type": "screen",
            "controls": [
                {
                    "background": {
                        "type": "image",
                        "size": ["100%", "100%"],
                        "texture": "textures/ui/title_background"
                    }
                },
                {
                    "logo": {
                        "type": "image",
                        "anchor_from": "top_middle",
                        "anchor_to": "top_middle",
                        "size": [300, 80],
                        "offset": [0, 40],
                        "texture": "textures/ui/title_logo"
                    }
                },
                {
                    "play_button": {
                        "type": "button",
                        "anchor_from": "center",
                        "anchor_to": "center",
                        "size": [200, 40],
                        "offset": [0, 40],
                        "texture": "textures/ui/button_default"
                    }
                }
            ]
        }
    })
}

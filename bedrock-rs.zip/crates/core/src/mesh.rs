//! Chunk meshing — greedy-ish face emission for solid blocks.

use crate::block::{BlockId, BlockState};
use crate::world::Chunk;
use glam::Vec3;

#[derive(Debug, Clone, Copy)]
pub struct MeshVertex {
    pub pos: [f32; 3],
    pub color: [f32; 4],
    pub normal: [f32; 3],
}

#[derive(Debug, Default, Clone)]
pub struct ChunkMesh {
    pub vertices: Vec<MeshVertex>,
    pub indices: Vec<u32>,
}

fn block_color(id: BlockId) -> [f32; 4] {
    match id {
        BlockId::GRASS => [0.30, 0.70, 0.25, 1.0],
        BlockId::DIRT => [0.45, 0.30, 0.15, 1.0],
        BlockId::STONE => [0.55, 0.55, 0.55, 1.0],
        BlockId::BEDROCK => [0.2, 0.2, 0.2, 1.0],
        _ => [1.0, 0.0, 1.0, 1.0],
    }
}

fn is_solid(b: &BlockState) -> bool {
    b.id != BlockId::AIR
}

/// Emit faces only where a solid block meets air (or edge).
pub fn mesh_chunk(chunk: &Chunk) -> ChunkMesh {
    let mut mesh = ChunkMesh::default();
    let ox = (chunk.pos.x * 16) as f32;
    let oz = (chunk.pos.z * 16) as f32;
    let min_y = Chunk::MIN_Y;

    for y in 0..Chunk::SIZE_Y {
        for z in 0..Chunk::SIZE_Z {
            for x in 0..Chunk::SIZE_X {
                let b = chunk.get(x, y, z);
                if !is_solid(b) {
                    continue;
                }
                let color = block_color(b.id);
                let wx = ox + x as f32;
                let wy = (min_y + y as i32) as f32;
                let wz = oz + z as f32;

                // 6 faces: +X -X +Y -Y +Z -Z
                let neighbors = [
                    (1i32, 0, 0, [1.0f32, 0.0, 0.0]),
                    (-1, 0, 0, [-1.0, 0.0, 0.0]),
                    (0, 1, 0, [0.0, 1.0, 0.0]),
                    (0, -1, 0, [0.0, -1.0, 0.0]),
                    (0, 0, 1, [0.0, 0.0, 1.0]),
                    (0, 0, -1, [0.0, 0.0, -1.0]),
                ];

                for (dx, dy, dz, normal) in neighbors {
                    let nx = x as i32 + dx;
                    let ny = y as i32 + dy;
                    let nz = z as i32 + dz;
                    let expose = if nx < 0
                        || ny < 0
                        || nz < 0
                        || nx >= Chunk::SIZE_X as i32
                        || ny >= Chunk::SIZE_Y as i32
                        || nz >= Chunk::SIZE_Z as i32
                    {
                        true
                    } else {
                        !is_solid(chunk.get(nx as usize, ny as usize, nz as usize))
                    };
                    if !expose {
                        continue;
                    }
                    emit_face(
                        &mut mesh,
                        wx,
                        wy,
                        wz,
                        dx,
                        dy,
                        dz,
                        color,
                        normal,
                    );
                }
            }
        }
    }
    mesh
}

fn emit_face(
    mesh: &mut ChunkMesh,
    x: f32,
    y: f32,
    z: f32,
    dx: i32,
    dy: i32,
    dz: i32,
    color: [f32; 4],
    normal: [f32; 3],
) {
    // 4 corners of the face relative to block origin
    let (v0, v1, v2, v3) = match (dx, dy, dz) {
        (1, 0, 0) => (
            [x + 1.0, y, z],
            [x + 1.0, y, z + 1.0],
            [x + 1.0, y + 1.0, z + 1.0],
            [x + 1.0, y + 1.0, z],
        ),
        (-1, 0, 0) => (
            [x, y, z + 1.0],
            [x, y, z],
            [x, y + 1.0, z],
            [x, y + 1.0, z + 1.0],
        ),
        (0, 1, 0) => (
            [x, y + 1.0, z + 1.0],
            [x + 1.0, y + 1.0, z + 1.0],
            [x + 1.0, y + 1.0, z],
            [x, y + 1.0, z],
        ),
        (0, -1, 0) => (
            [x, y, z],
            [x + 1.0, y, z],
            [x + 1.0, y, z + 1.0],
            [x, y, z + 1.0],
        ),
        (0, 0, 1) => (
            [x + 1.0, y, z + 1.0],
            [x, y, z + 1.0],
            [x, y + 1.0, z + 1.0],
            [x + 1.0, y + 1.0, z + 1.0],
        ),
        (0, 0, -1) => (
            [x, y, z],
            [x + 1.0, y, z],
            [x + 1.0, y + 1.0, z],
            [x, y + 1.0, z],
        ),
        _ => return,
    };

    let base = mesh.vertices.len() as u32;
    for p in [v0, v1, v2, v3] {
        mesh.vertices.push(MeshVertex {
            pos: p,
            color,
            normal,
        });
    }
    // two triangles
    mesh.indices.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
}

//! Minimal NBT reader/writer (Bedrock little-endian variant later).
//! This is a stub so the rest of the engine compiles.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum NbtTag {
    End,
    Byte(i8),
    Short(i16),
    Int(i32),
    Long(i64),
    Float(f32),
    Double(f64),
    String(String),
    List(Vec<NbtTag>),
    Compound(Vec<(String, NbtTag)>),
}

impl NbtTag {
    pub fn compound_empty() -> Self {
        NbtTag::Compound(Vec::new())
    }
}

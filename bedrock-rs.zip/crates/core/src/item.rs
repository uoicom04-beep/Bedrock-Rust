use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ItemStack {
    pub id: u32,
    pub count: u8,
    pub damage: u16,
    pub name: Option<String>,
}

impl ItemStack {
    pub fn empty() -> Self {
        Self {
            id: 0,
            count: 0,
            damage: 0,
            name: None,
        }
    }
}

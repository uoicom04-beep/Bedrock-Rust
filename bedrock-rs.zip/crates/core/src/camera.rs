//! First-person camera from player entity.

use crate::entity::Entity;
use glam::{Mat4, Vec3};

#[derive(Debug, Clone)]
pub struct Camera {
    pub pos: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub fov_y: f32,
    pub near: f32,
    pub far: f32,
}

impl Default for Camera {
    fn default() -> Self {
        Self {
            pos: Vec3::new(0.0, 80.0, 0.0),
            yaw: 0.0,
            pitch: 0.0,
            fov_y: 70.0_f32.to_radians(),
            near: 0.05,
            far: 512.0,
        }
    }
}

impl Camera {
    pub fn from_entity(entity: &Entity) -> Self {
        Self {
            pos: entity.eye_pos(),
            yaw: entity.yaw,
            pitch: entity.pitch,
            ..Default::default()
        }
    }

    pub fn view_matrix(&self) -> Mat4 {
        let dir = {
            let yaw = self.yaw.to_radians();
            let pitch = self.pitch.to_radians();
            Vec3::new(
                -yaw.sin() * pitch.cos(),
                -pitch.sin(),
                yaw.cos() * pitch.cos(),
            )
            .normalize_or_zero()
        };
        Mat4::look_to_rh(self.pos, dir, Vec3::Y)
    }

    pub fn projection_matrix(&self, aspect: f32) -> Mat4 {
        Mat4::perspective_rh(self.fov_y, aspect, self.near, self.far)
    }

    pub fn view_proj(&self, aspect: f32) -> Mat4 {
        self.projection_matrix(aspect) * self.view_matrix()
    }
}

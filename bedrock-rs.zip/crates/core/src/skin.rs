//! Player skin loader (Bedrock/Java 64x64 PNG).
//! Place skins in ./skins/*.png or set BEDROCK_SKINS path.

use anyhow::{Context, Result};
use image::RgbaImage;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone)]
pub struct Skin {
    pub name: String,
    pub path: PathBuf,
    pub image: RgbaImage,
    pub width: u32,
    pub height: u32,
}

impl Skin {
    pub fn load(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref().to_path_buf();
        let img = image::open(&path)
            .with_context(|| format!("open skin {}", path.display()))?
            .to_rgba8();
        let (width, height) = img.dimensions();
        let name = path
            .file_stem()
            .and_then(|s| s.to_str())
            .unwrap_or("skin")
            .to_string();
        Ok(Self {
            name,
            path,
            image: img,
            width,
            height,
        })
    }

    /// Classic Steve placeholder 64x64 solid colors (no Mojang art).
    pub fn placeholder_steve() -> Self {
        let mut img = RgbaImage::new(64, 64);
        // simple colored regions approximating skin layout
        for y in 0..64 {
            for x in 0..64 {
                let c = if y < 16 && x >= 8 && x < 24 {
                    // head
                    [200, 160, 120, 255]
                } else if y >= 16 && y < 36 && x >= 20 && x < 28 {
                    // body
                    [40, 40, 180, 255]
                } else {
                    [0, 0, 0, 0]
                };
                img.put_pixel(x, y, image::Rgba(c));
            }
        }
        Self {
            name: "Steve".into(),
            path: PathBuf::from("builtin:steve"),
            image: img,
            width: 64,
            height: 64,
        }
    }
}

#[derive(Debug, Default)]
pub struct SkinStore {
    pub skins: Vec<Skin>,
    pub selected: usize,
}

impl SkinStore {
    pub fn new() -> Self {
        let mut s = Self::default();
        s.skins.push(Skin::placeholder_steve());
        s
    }

    pub fn load_folder(&mut self, dir: impl AsRef<Path>) -> Result<usize> {
        let dir = dir.as_ref();
        if !dir.is_dir() {
            return Ok(0);
        }
        let mut n = 0;
        for e in fs::read_dir(dir)? {
            let e = e?;
            let p = e.path();
            if p.extension().and_then(|x| x.to_str()) == Some("png") {
                match Skin::load(&p) {
                    Ok(skin) => {
                        log::info!("Skin loaded: {}", skin.name);
                        self.skins.push(skin);
                        n += 1;
                    }
                    Err(err) => log::warn!("skin {}: {:#}", p.display(), err),
                }
            }
        }
        Ok(n)
    }

    pub fn current(&self) -> &Skin {
        &self.skins[self.selected.min(self.skins.len().saturating_sub(1))]
    }

    pub fn select(&mut self, i: usize) {
        if i < self.skins.len() {
            self.selected = i;
        }
    }

    pub fn next(&mut self) {
        if !self.skins.is_empty() {
            self.selected = (self.selected + 1) % self.skins.len();
        }
    }
}

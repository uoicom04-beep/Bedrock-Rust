//! Entity system — players, mobs, items in the world.

use glam::{Vec3, Vec2};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct EntityId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EntityKind {
    Player,
    Zombie,
    Skeleton,
    Creeper,
    Item,
    Other,
}

#[derive(Debug, Clone)]
pub struct Entity {
    pub id: EntityId,
    pub kind: EntityKind,
    pub uuid: Uuid,
    pub pos: Vec3,
    pub vel: Vec3,
    pub yaw: f32,   // degrees
    pub pitch: f32, // degrees
    pub health: f32,
    pub max_health: f32,
    pub on_ground: bool,
    pub width: f32,
    pub height: f32,
    pub name: Option<String>,
}

impl Entity {
    pub fn player(id: EntityId, pos: Vec3) -> Self {
        Self {
            id,
            kind: EntityKind::Player,
            uuid: Uuid::new_v4(),
            pos,
            vel: Vec3::ZERO,
            yaw: 0.0,
            pitch: 0.0,
            health: 20.0,
            max_health: 20.0,
            on_ground: false,
            width: 0.6,
            height: 1.8,
            name: Some("Player".into()),
        }
    }

    pub fn mob(id: EntityId, kind: EntityKind, pos: Vec3) -> Self {
        let (hp, w, h) = match kind {
            EntityKind::Zombie => (20.0, 0.6, 1.95),
            EntityKind::Skeleton => (20.0, 0.6, 1.99),
            EntityKind::Creeper => (20.0, 0.6, 1.7),
            _ => (10.0, 0.6, 1.0),
        };
        Self {
            id,
            kind,
            uuid: Uuid::new_v4(),
            pos,
            vel: Vec3::ZERO,
            yaw: 0.0,
            pitch: 0.0,
            health: hp,
            max_health: hp,
            on_ground: false,
            width: w,
            height: h,
            name: None,
        }
    }

    pub fn eye_pos(&self) -> Vec3 {
        self.pos + Vec3::new(0.0, self.height * 0.85, 0.0)
    }

    pub fn look_dir(&self) -> Vec3 {
        let yaw = self.yaw.to_radians();
        let pitch = self.pitch.to_radians();
        Vec3::new(
            -yaw.sin() * pitch.cos(),
            -pitch.sin(),
            yaw.cos() * pitch.cos(),
        )
        .normalize_or_zero()
    }

    pub fn aabb_min(&self) -> Vec3 {
        Vec3::new(
            self.pos.x - self.width * 0.5,
            self.pos.y,
            self.pos.z - self.width * 0.5,
        )
    }

    pub fn aabb_max(&self) -> Vec3 {
        Vec3::new(
            self.pos.x + self.width * 0.5,
            self.pos.y + self.height,
            self.pos.z + self.width * 0.5,
        )
    }
}

#[derive(Debug, Default)]
pub struct EntityWorld {
    pub next_id: u64,
    pub entities: Vec<Entity>,
    pub local_player: Option<EntityId>,
}

impl EntityWorld {
    pub fn spawn_player(&mut self, pos: Vec3) -> EntityId {
        let id = EntityId(self.next_id);
        self.next_id += 1;
        let e = Entity::player(id, pos);
        self.entities.push(e);
        self.local_player = Some(id);
        id
    }

    pub fn spawn_mob(&mut self, kind: EntityKind, pos: Vec3) -> EntityId {
        let id = EntityId(self.next_id);
        self.next_id += 1;
        self.entities.push(Entity::mob(id, kind, pos));
        id
    }

    pub fn get(&self, id: EntityId) -> Option<&Entity> {
        self.entities.iter().find(|e| e.id == id)
    }

    pub fn get_mut(&mut self, id: EntityId) -> Option<&mut Entity> {
        self.entities.iter_mut().find(|e| e.id == id)
    }

    pub fn local_player(&self) -> Option<&Entity> {
        self.local_player.and_then(|id| self.get(id))
    }

    pub fn local_player_mut(&mut self) -> Option<&mut Entity> {
        let id = self.local_player?;
        self.get_mut(id)
    }
}

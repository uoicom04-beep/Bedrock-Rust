//! Bedrock-RS core: blocks, items, world primitives, NBT, resource packs.

pub mod block;
pub mod item;
pub mod nbt;
pub mod resource_pack;
pub mod world;
pub mod ui;
pub mod inventory;
pub mod mesh;
pub mod camera;
pub mod physics;
pub mod entity;
pub mod skin;

pub use block::{BlockId, BlockState};
pub use item::ItemStack;
pub use resource_pack::{ResourcePack, ResourcePackManager};
pub use world::{ChunkPos, World};
pub use ui::UiManager;
pub use entity::{Entity, EntityId, EntityKind, EntityWorld};
pub use camera::Camera;
pub use inventory::Inventory;
pub use mesh::{ChunkMesh, mesh_chunk};
pub use skin::{Skin, SkinStore};


/// Protocol / game version this skeleton targets (Bedrock 1.21.x style).
pub const PROTOCOL_VERSION: u32 = 686;
pub const GAME_VERSION: &str = "1.21.50";
pub const ENGINE_NAME: &str = "Bedrock-RS";
pub const ENGINE_VERSION: &str = "0.1.0";

//! Bedrock-style resource pack loader.
//! Reads `manifest.json` + textures from a folder or .mcpack/.zip.

use anyhow::{bail, Context, Result};
use image::RgbaImage;
use serde::Deserialize;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Deserialize)]
pub struct ManifestHeader {
    pub name: String,
    pub description: String,
    pub uuid: String,
    pub version: Vec<u32>,
}

#[derive(Debug, Deserialize)]
pub struct ManifestModule {
    #[serde(rename = "type")]
    pub module_type: String,
    pub uuid: String,
    pub version: Vec<u32>,
}

#[derive(Debug, Deserialize)]
pub struct Manifest {
    pub format_version: u32,
    pub header: ManifestHeader,
    pub modules: Vec<ManifestModule>,
}

#[derive(Debug)]
pub struct ResourcePack {
    pub path: PathBuf,
    pub manifest: Manifest,
    pub textures: HashMap<String, RgbaImage>,
}

impl ResourcePack {
    pub fn load(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref().to_path_buf();
        let manifest_path = path.join("manifest.json");
        let data = fs::read_to_string(&manifest_path)
            .with_context(|| format!("read {}", manifest_path.display()))?;
        let manifest: Manifest = serde_json::from_str(&data)?;

        let mut textures = HashMap::new();
        let tex_root = path.join("textures");
        if tex_root.is_dir() {
            load_textures_recursive(&tex_root, &tex_root, &mut textures)?;
        }

        Ok(Self {
            path,
            manifest,
            textures,
        })
    }

    pub fn texture(&self, name: &str) -> Option<&RgbaImage> {
        self.textures.get(name)
    }
}

fn load_textures_recursive(
    root: &Path,
    dir: &Path,
    out: &mut HashMap<String, RgbaImage>,
) -> Result<()> {
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let p = entry.path();
        if p.is_dir() {
            load_textures_recursive(root, &p, out)?;
        } else if p.extension().and_then(|e| e.to_str()) == Some("png") {
            let rel = p.strip_prefix(root)?.to_string_lossy().replace('\\', "/");
            let key = rel.trim_end_matches(".png").to_string();
            match image::open(&p) {
                Ok(img) => {
                    out.insert(key, img.to_rgba8());
                }
                Err(e) => log::warn!("skip texture {}: {}", p.display(), e),
            }
        }
    }
    Ok(())
}

#[derive(Debug, Default)]
pub struct ResourcePackManager {
    packs: Vec<ResourcePack>,
}

impl ResourcePackManager {
    pub fn new() -> Self {
        Self { packs: Vec::new() }
    }

    pub fn add_pack(&mut self, pack: ResourcePack) {
        log::info!(
            "Loaded resource pack: {} ({})",
            pack.manifest.header.name,
            pack.path.display()
        );
        self.packs.push(pack);
    }

    pub fn load_folder(&mut self, folder: impl AsRef<Path>) -> Result<()> {
        let folder = folder.as_ref();
        if !folder.is_dir() {
            bail!("{} is not a directory", folder.display());
        }
        // Each subfolder that has manifest.json is a pack
        for entry in fs::read_dir(folder)? {
            let entry = entry?;
            let p = entry.path();
            if p.join("manifest.json").is_file() {
                match ResourcePack::load(&p) {
                    Ok(pack) => self.add_pack(pack),
                    Err(e) => log::error!("failed to load {}: {:#}", p.display(), e),
                }
            }
        }
        Ok(())
    }

    /// Search packs from last to first (top pack wins).
    pub fn texture(&self, name: &str) -> Option<&RgbaImage> {
        for pack in self.packs.iter().rev() {
            if let Some(img) = pack.texture(name) {
                return Some(img);
            }
        }
        None
    }
}

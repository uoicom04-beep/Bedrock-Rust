//! Player inventory + hotbar logic.

use crate::item::ItemStack;
use serde::{Deserialize, Serialize};

pub const HOTBAR_SIZE: usize = 9;
pub const MAIN_SIZE: usize = 27;
pub const INV_SIZE: usize = HOTBAR_SIZE + MAIN_SIZE; // 36

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Inventory {
    pub slots: Vec<ItemStack>,
    pub selected: usize, // 0..8 hotbar index
}

impl Default for Inventory {
    fn default() -> Self {
        let mut slots = vec![ItemStack::empty(); INV_SIZE];
        // starter items for testing
        slots[0] = ItemStack {
            id: 1, // stone
            count: 64,
            damage: 0,
            name: Some("Stone".into()),
        };
        slots[1] = ItemStack {
            id: 2,
            count: 32,
            damage: 0,
            name: Some("Grass".into()),
        };
        Self {
            slots,
            selected: 0,
        }
    }
}

impl Inventory {
    pub fn selected_stack(&self) -> &ItemStack {
        &self.slots[self.selected]
    }

    pub fn selected_stack_mut(&mut self) -> &mut ItemStack {
        &mut self.slots[self.selected]
    }

    pub fn select_hotbar(&mut self, index: usize) {
        if index < HOTBAR_SIZE {
            self.selected = index;
        }
    }

    pub fn scroll_hotbar(&mut self, delta: i32) {
        let n = HOTBAR_SIZE as i32;
        let mut s = self.selected as i32 + delta;
        s = ((s % n) + n) % n;
        self.selected = s as usize;
    }

    /// Consume 1 from selected stack. Returns true if something was used.
    pub fn use_selected(&mut self) -> bool {
        let stack = self.selected_stack_mut();
        if stack.count == 0 || stack.id == 0 {
            return false;
        }
        stack.count -= 1;
        if stack.count == 0 {
            *stack = ItemStack::empty();
        }
        true
    }

    pub fn give(&mut self, item: ItemStack) -> bool {
        // stack into existing
        for s in &mut self.slots {
            if s.id == item.id && s.id != 0 && s.count < 64 {
                let space = 64 - s.count;
                let add = space.min(item.count);
                s.count += add;
                if add == item.count {
                    return true;
                }
            }
        }
        // empty slot
        for s in &mut self.slots {
            if s.id == 0 || s.count == 0 {
                *s = item;
                return true;
            }
        }
        false
    }
}

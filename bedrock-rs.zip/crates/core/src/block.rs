use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct BlockId(pub u32);

impl BlockId {
    pub const AIR: BlockId = BlockId(0);
    pub const STONE: BlockId = BlockId(1);
    pub const GRASS: BlockId = BlockId(2);
    pub const DIRT: BlockId = BlockId(3);
    pub const BEDROCK: BlockId = BlockId(7);
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BlockState {
    pub id: BlockId,
    pub meta: u16,
}

impl Default for BlockState {
    fn default() -> Self {
        Self {
            id: BlockId::AIR,
            meta: 0,
        }
    }
}

use crate::block::{BlockId, BlockState};
use glam::IVec3;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ChunkPos {
    pub x: i32,
    pub z: i32,
}

impl ChunkPos {
    pub fn new(x: i32, z: i32) -> Self {
        Self { x, z }
    }
}

/// 16×16×384 (1.18+ style height) simplified storage.
#[derive(Debug, Clone)]
pub struct Chunk {
    pub pos: ChunkPos,
    /// Flat array: y * 256 + z * 16 + x
    pub blocks: Vec<BlockState>,
}

impl Chunk {
    pub const SIZE_X: usize = 16;
    pub const SIZE_Z: usize = 16;
    pub const SIZE_Y: usize = 384;
    pub const MIN_Y: i32 = -64;

    pub fn new(pos: ChunkPos) -> Self {
        let total = Self::SIZE_X * Self::SIZE_Y * Self::SIZE_Z;
        let mut blocks = vec![BlockState::default(); total];

        // Simple flat world for testing
        for y in 0..64 {
            for z in 0..Self::SIZE_Z {
                for x in 0..Self::SIZE_X {
                    let idx = y * 256 + z * 16 + x;
                    if y < 60 {
                        blocks[idx] = BlockState {
                            id: BlockId::STONE,
                            meta: 0,
                        };
                    } else if y < 63 {
                        blocks[idx] = BlockState {
                            id: BlockId::DIRT,
                            meta: 0,
                        };
                    } else {
                        blocks[idx] = BlockState {
                            id: BlockId::GRASS,
                            meta: 0,
                        };
                    }
                }
            }
        }

        Self { pos, blocks }
    }

    pub fn get(&self, x: usize, y: usize, z: usize) -> &BlockState {
        &self.blocks[y * 256 + z * 16 + x]
    }
}

#[derive(Debug, Default)]
pub struct World {
    pub chunks: HashMap<ChunkPos, Chunk>,
    pub name: String,
    pub seed: i64,
}

impl World {
    pub fn new(name: impl Into<String>, seed: i64) -> Self {
        Self {
            chunks: HashMap::new(),
            name: name.into(),
            seed,
        }
    }

    pub fn get_or_create_chunk(&mut self, pos: ChunkPos) -> &Chunk {
        self.chunks
            .entry(pos)
            .or_insert_with(|| Chunk::new(pos))
    }

    pub fn block_at(&mut self, pos: IVec3) -> BlockState {
        let cx = pos.x.div_euclid(16);
        let cz = pos.z.div_euclid(16);
        let lx = pos.x.rem_euclid(16) as usize;
        let lz = pos.z.rem_euclid(16) as usize;
        let y = (pos.y - Chunk::MIN_Y) as usize;
        if y >= Chunk::SIZE_Y {
            return BlockState::default();
        }
        let chunk = self.get_or_create_chunk(ChunkPos::new(cx, cz));
        chunk.get(lx, y, lz).clone()
    }
}

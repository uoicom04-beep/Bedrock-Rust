//! Simple AABB physics + block collision against the flat world.

use crate::block::BlockId;
use crate::entity::Entity;
use crate::world::{Chunk, World};
use glam::{IVec3, Vec3};

const GRAVITY: f32 = -32.0;
const TERMINAL: f32 = -78.0;
const STEP_HEIGHT: f32 = 0.5;

pub struct PhysicsInput {
    pub forward: f32, // -1..1
    pub strafe: f32,
    pub jump: bool,
    pub sneak: bool,
    pub sprint: bool,
}

impl Default for PhysicsInput {
    fn default() -> Self {
        Self {
            forward: 0.0,
            strafe: 0.0,
            jump: false,
            sneak: false,
            sprint: false,
        }
    }
}

fn block_solid(world: &mut World, x: i32, y: i32, z: i32) -> bool {
    let st = world.block_at(IVec3::new(x, y, z));
    st.id != BlockId::AIR
}

/// Move entity with gravity + axis-separated collision.
pub fn tick_entity(entity: &mut Entity, world: &mut World, input: &PhysicsInput, dt: f32) {
    // Horizontal wish direction from yaw
    let yaw = entity.yaw.to_radians();
    let forward = Vec3::new(-yaw.sin(), 0.0, yaw.cos());
    let right = Vec3::new(forward.z, 0.0, -forward.x);
    let mut wish = forward * input.forward + right * input.strafe;
    if wish.length_squared() > 0.0 {
        wish = wish.normalize();
    }

    let speed = if input.sprint { 5.6 } else { 4.3 };
    let accel = if entity.on_ground { 50.0 } else { 8.0 };

    // accelerate
    let wish_vel = wish * speed;
    let mut hvel = Vec3::new(entity.vel.x, 0.0, entity.vel.z);
    let diff = wish_vel - hvel;
    hvel += diff * (accel * dt).min(1.0);
    entity.vel.x = hvel.x;
    entity.vel.z = hvel.z;

    // jump
    if input.jump && entity.on_ground {
        entity.vel.y = 9.0;
        entity.on_ground = false;
    }

    // gravity
    entity.vel.y += GRAVITY * dt;
    if entity.vel.y < TERMINAL {
        entity.vel.y = TERMINAL;
    }

    // integrate with collision per axis
    let mut pos = entity.pos;
    let half_w = entity.width * 0.5;
    let height = entity.height;

    // X
    pos.x += entity.vel.x * dt;
    if collides(world, pos, half_w, height) {
        pos.x = entity.pos.x;
        entity.vel.x = 0.0;
    }

    // Z
    pos.z += entity.vel.z * dt;
    if collides(world, pos, half_w, height) {
        pos.z = entity.pos.z;
        entity.vel.z = 0.0;
    }

    // Y
    pos.y += entity.vel.y * dt;
    entity.on_ground = false;
    if collides(world, pos, half_w, height) {
        if entity.vel.y < 0.0 {
            // land
            entity.on_ground = true;
            // snap to top of block
            let feet = pos.y.floor() as i32;
            pos.y = feet as f32 + 1.0;
        }
        entity.vel.y = 0.0;
    }

    entity.pos = pos;

    // friction on ground
    if entity.on_ground {
        entity.vel.x *= 0.6;
        entity.vel.z *= 0.6;
        if entity.vel.x.abs() < 0.01 {
            entity.vel.x = 0.0;
        }
        if entity.vel.z.abs() < 0.01 {
            entity.vel.z = 0.0;
        }
    }
}

fn collides(world: &mut World, pos: Vec3, half_w: f32, height: f32) -> bool {
    let min = Vec3::new(pos.x - half_w, pos.y, pos.z - half_w);
    let max = Vec3::new(pos.x + half_w, pos.y + height, pos.z + half_w);
    let x0 = min.x.floor() as i32;
    let y0 = min.y.floor() as i32;
    let z0 = min.z.floor() as i32;
    let x1 = max.x.floor() as i32;
    let y1 = max.y.floor() as i32;
    let z1 = max.z.floor() as i32;
    for y in y0..=y1 {
        for z in z0..=z1 {
            for x in x0..=x1 {
                if block_solid(world, x, y, z) {
                    return true;
                }
            }
        }
    }
    false
}

/// Look input (mouse / touch delta in degrees).
pub fn apply_look(entity: &mut Entity, dx: f32, dy: f32, sensitivity: f32) {
    entity.yaw -= dx * sensitivity;
    entity.pitch -= dy * sensitivity;
    entity.pitch = entity.pitch.clamp(-89.0, 89.0);
    if entity.yaw > 360.0 || entity.yaw < -360.0 {
        entity.yaw %= 360.0;
    }
}

Place 64x64 PNG skins here

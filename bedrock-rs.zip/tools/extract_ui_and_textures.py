#!/usr/bin/env python3
"""
Extract UI JSON + textures from an installed Minecraft Bedrock copy.
Run this on YOUR machine that has the game. Output is used by Bedrock-RS.

Windows example source:
  %LOCALAPPDATA%\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState\\games\\com.mojang

Or from an extracted APK / Android backup:
  games/com.mojang/resource_packs
  or the assets inside the official package.

Usage:
  python tools/extract_ui_and_textures.py --src "C:/path/to/com.mojang" --out ./extracted_bedrock
"""

import argparse
import json
import os
import shutil
import sys
import uuid
from pathlib import Path

def find_candidates(src: Path):
    paths = [
        src,
        src / "resource_packs",
        src / "data" / "resource_packs",
        src / "games" / "com.mojang" / "resource_packs",
        src / "assets",
    ]
    return [p for p in paths if p.exists()]

def copy_tree_if(src: Path, dest: Path, names):
    """Copy matching subfolders/files."""
    copied = 0
    if not src.exists():
        return 0
    for name in names:
        s = src / name
        if s.is_dir():
            d = dest / name
            d.mkdir(parents=True, exist_ok=True)
            shutil.copytree(s, d, dirs_exist_ok=True)
            copied += 1
            print(f"  + dir {name}")
        elif s.is_file():
            dest.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, dest / name)
            copied += 1
            print(f"  + file {name}")
    return copied

def ensure_manifest(pack_dir: Path, name: str):
    man = pack_dir / "manifest.json"
    if man.is_file():
        return
    data = {
        "format_version": 2,
        "header": {
            "name": name,
            "description": "Extracted from local Bedrock install",
            "uuid": str(uuid.uuid4()),
            "version": [1, 0, 0],
            "min_engine_version": [1, 21, 0],
        },
        "modules": [
            {
                "type": "resources",
                "uuid": str(uuid.uuid4()),
                "version": [1, 0, 0],
            }
        ],
    }
    with open(man, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="Path to com.mojang or resource_packs root")
    ap.add_argument("--out", default="./extracted_bedrock")
    args = ap.parse_args()

    src = Path(args.src)
    out = Path(args.out)
    if not src.exists():
        print(f"Source not found: {src}", file=sys.stderr)
        sys.exit(1)

    out.mkdir(parents=True, exist_ok=True)
    ui_out = out / "ui"
    tex_out = out / "textures"
    packs_out = out / "resource_packs"
    ui_out.mkdir(exist_ok=True)
    tex_out.mkdir(exist_ok=True)
    packs_out.mkdir(exist_ok=True)

    print("Scanning for UI + textures...")
    total = 0
    for root in find_candidates(src):
        print(f"Scan: {root}")
        # UI definitions
        for ui_name in ("ui", "UI", "gui"):
            total += copy_tree_if(root, ui_out, [ui_name])
            # sometimes nested inside a pack
            for pack in root.iterdir() if root.is_dir() else []:
                if pack.is_dir():
                    total += copy_tree_if(pack, ui_out, [ui_name])

        # Textures
        for tname in ("textures", "Textures"):
            total += copy_tree_if(root, tex_out, [tname])
            for pack in root.iterdir() if root.is_dir() else []:
                if pack.is_dir():
                    dest_pack = packs_out / pack.name
                    if copy_tree_if(pack, dest_pack, [tname, "ui", "texts", "font"]):
                        ensure_manifest(dest_pack, pack.name)
                        total += 1

        # Whole packs that already look like Bedrock packs
        if (root / "manifest.json").is_file():
            dest = packs_out / root.name
            shutil.copytree(root, dest, dirs_exist_ok=True)
            print(f"  + pack {root.name}")
            total += 1

    # Write a small index so the client knows where things are
    index = {
        "ui": str(ui_out.resolve()),
        "textures": str(tex_out.resolve()),
        "resource_packs": str(packs_out.resolve()),
    }
    with open(out / "bedrock_rs_index.json", "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2)

    print()
    print(f"Done. Extracted pieces → {out}")
    print("Set environment variables before running the client:")
    print(f'  export BEDROCK_UI="{ui_out.resolve()}"')
    print(f'  export BEDROCK_TEXTURES="{packs_out.resolve()}"')
    print("Then: cargo run -p bedrock-client")
    if total == 0:
        print("WARNING: nothing copied. Check --src path.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Extract textures from an installed Minecraft Bedrock (Windows / Android backup).
Usage:
  python tools/extract_textures.py --src "C:/Users/.../MinecraftBE" --out ./extracted_packs

The script looks for resource_packs / vanilla textures and copies them into a
Bedrock-style pack folder that Bedrock-RS can load.
"""

import argparse
import json
import os
import shutil
import sys
import uuid
from pathlib import Path

def find_texture_roots(src: Path):
    candidates = [
        src / "data" / "resource_packs",
        src / "resource_packs",
        src / "assets" / "resource_packs",
        src / "games" / "com.mojang" / "resource_packs",
    ]
    return [p for p in candidates if p.is_dir()]

def make_manifest(name: str, desc: str):
    return {
        "format_version": 2,
        "header": {
            "name": name,
            "description": desc,
            "uuid": str(uuid.uuid4()),
            "version": [1, 0, 0],
            "min_engine_version": [1, 21, 0],
        },
        "modules": [
            {
                "type": "resources",
                "uuid": str(uuid.uuid4()),
                "version": [1, 0, 0],
            }
        ],
    }

def copy_pack(src_pack: Path, dest: Path):
    if not (src_pack / "manifest.json").is_file() and not (src_pack / "textures").is_dir():
        return False
    dest.mkdir(parents=True, exist_ok=True)
    # copy textures
    tex = src_pack / "textures"
    if tex.is_dir():
        shutil.copytree(tex, dest / "textures", dirs_exist_ok=True)
    # manifest
    man = src_pack / "manifest.json"
    if man.is_file():
        shutil.copy2(man, dest / "manifest.json")
    else:
        with open(dest / "manifest.json", "w", encoding="utf-8") as f:
            json.dump(make_manifest(src_pack.name, "Extracted"), f, indent=2)
    return True

def main():
    ap = argparse.ArgumentParser(description="Extract Bedrock textures for Bedrock-RS")
    ap.add_argument("--src", required=True, help="Path to Minecraft Bedrock install or com.mojang")
    ap.add_argument("--out", default="./extracted_packs", help="Output folder")
    args = ap.parse_args()

    src = Path(args.src)
    out = Path(args.out)
    if not src.is_dir():
        print(f"Source not found: {src}", file=sys.stderr)
        sys.exit(1)

    roots = find_texture_roots(src)
    if not roots:
        # maybe src itself is a pack
        roots = [src]

    out.mkdir(parents=True, exist_ok=True)
    count = 0
    for root in roots:
        for child in root.iterdir():
            if child.is_dir():
                dest = out / child.name
                if copy_pack(child, dest):
                    print(f"Copied pack: {child.name}")
                    count += 1
        # also try root itself
        if copy_pack(root, out / root.name):
            print(f"Copied pack: {root.name}")
            count += 1

    print(f"Done. {count} pack(s) → {out}")
    print("Set env BEDROCK_TEXTURES to this folder when running the client.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Package a Bedrock-RS native addon (cdylib) + optional behavior JSON into a .mcaddon-like zip."""

import argparse
import zipfile
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib", required=True, help="Path to .so / .dylib / .dll")
    ap.add_argument("--out", default="example_addon.mcaddon")
    ap.add_argument("--name", default="Example Rust Addon")
    args = ap.parse_args()

    lib = Path(args.lib)
    out = Path(args.out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(lib, f"native/{lib.name}")
        z.writestr(
            "manifest.json",
            f'''{{
  "format_version": 2,
  "header": {{
    "name": "{args.name}",
    "description": "Native Rust addon for Bedrock-RS",
    "uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "version": [0, 1, 0]
  }},
  "modules": [{{
    "type": "javascript",
    "uuid": "b2c3d4e5-f6a7-8901-bcde-f12345678901",
    "version": [0, 1, 0]
  }}]
}}
''',
        )
    print(f"Wrote {out}")

if __name__ == "__main__":
    main()
